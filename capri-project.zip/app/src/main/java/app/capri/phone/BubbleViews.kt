package app.capri.phone

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout

/** Dark panel with cyan outline, cut corners and a tail pointing down at Capri. */
class BubbleBg(private val tailH: Int, private val d: Float) : Drawable() {
    var tailFrac = 0.6f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEB0A0A10.toInt(); style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF28E2EC.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * d; strokeJoin = Paint.Join.MITER
    }

    override fun draw(c: Canvas) {
        val r = bounds
        val s = line.strokeWidth / 2f
        val l = r.left + s
        val t = r.top + s
        val rt = r.right - s
        val b = r.bottom - tailH - s
        val ch = 14f * d
        val tx = r.left + r.width() * tailFrac
        val p = Path()
        p.moveTo(l + ch, t)
        p.lineTo(rt, t)
        p.lineTo(rt, b - ch)
        p.lineTo(rt - ch, b)
        p.lineTo(tx + 10f * d, b)
        p.lineTo(tx, r.bottom - s)
        p.lineTo(tx - 8f * d, b)
        p.lineTo(l, b)
        p.lineTo(l, t + ch)
        p.close()
        c.drawPath(p, fill)
        c.drawPath(p, line)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

class DashView(c: Context) : View(c) {
    private val p = Paint().apply {
        color = 0xFF1E828C.toInt()
        strokeWidth = resources.displayMetrics.density
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }

    override fun onDraw(cv: Canvas) {
        val y = height / 2f
        cv.drawLine(0f, y, width.toFloat(), y, p)
    }
}

/** Bubble container. Pressing Back while typing closes the keyboard. */
class BubbleRoot(c: Context, private val onBack: () -> Unit) : LinearLayout(c) {
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) {
            if (e.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(e)
    }
}
