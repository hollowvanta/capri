package app.capri.phone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Reply(val text: String, val ok: Boolean)

object Brain {
    val NAMES = arrayOf("NVIDIA (free key)", "Gemini", "OpenAI", "Claude")
    val MODELS = arrayOf("meta/llama-3.1-8b-instruct", "gemini-flash-latest", "gpt-4o-mini", "claude-haiku-5-5")
    private val BASES = arrayOf(
        "https://integrate.api.nvidia.com/v1",
        "https://generativelanguage.googleapis.com/v1beta/openai",
        "https://api.openai.com/v1",
        ""
    )
    private const val SYSTEM =
        "You are Capri, a playful, teasing chaos gremlin who lives on the user's phone screen as a small animated companion. " +
        "You are openly fond of the user. Reply in one or two short sentences, casual tone, no emojis, no markdown. " +
        "You cannot control the phone or open apps; if asked, say so playfully. Never claim to be a real person. " +
        "Stay kind and safe. If the user seems upset or in trouble, drop the act and respond with real care."
    private val rnd = java.util.Random()
    private fun pick(a: Array<String>) = a[rnd.nextInt(a.size)]

    fun ask(ctx: Context, history: List<Pair<String, String>>): Reply {
        val p = ctx.getSharedPreferences("capri", 0)
        val key = p.getString("key", "").orEmpty().trim()
        val last = history.lastOrNull()?.second ?: ""
        if (key.isEmpty()) {
            Thread.sleep(500)
            return Reply(local(last), true)
        }
        val prov = p.getInt("provider", 0).coerceIn(0, 3)
        val model = p.getString("model", "").orEmpty().trim().ifBlank { MODELS[prov] }
        return try {
            val turns = history.dropWhile { it.first != "user" }
            val msgs = JSONArray()
            for ((r, t) in turns) msgs.put(JSONObject().put("role", r).put("content", t))
            val (code, resp) = if (prov == 3) {
                val body = JSONObject().put("model", model).put("max_tokens", 200).put("system", SYSTEM).put("messages", msgs)
                post("https://api.anthropic.com/v1/messages",
                    mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
            } else {
                val all = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM))
                for (i in 0 until msgs.length()) all.put(msgs.get(i))
                val body = JSONObject().put("model", model).put("max_tokens", 200).put("messages", all)
                post(BASES[prov] + "/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
            }
            if (code !in 200..299) return Reply(errLine(code), false)
            val text = if (prov == 3) {
                JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
            } else {
                JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
            Reply(text.trim().ifEmpty { "..." }, true)
        } catch (e: Exception) {
            Reply("Brain's offline. Check your internet and try again.", false)
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val s = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return code to s
    }

    private fun errLine(code: Int) = when (code) {
        401, 403 -> "My brain says the key is wrong. Fix it in the Capri app."
        404 -> "That model name doesn't exist. Check it in the Capri app."
        429 -> "Too many messages at once. Give me a minute."
        else -> "Brain error $code. Try again later."
    }

    // Scripted replies when no key is saved.
    fun local(t: String): String {
        val s = t.lowercase()
        return when {
            Regex("\\b(hi|hello|hey|yo|sup)\\b").containsMatchIn(s) ->
                pick(arrayOf("Hey. Back already?", "Oh, hi. I was busy sitting on your screen.", "Hello. Behave."))
            "joke" in s -> pick(arrayOf("Why did the netrunner stay home? Too many bad connections.", "I told my cursor a secret. Now it won't stop following me."))
            "who are you" in s || "your name" in s -> "I'm Capri, a chaos gremlin who lives on your screen. Add a key in the app and I can really talk."
            "thank" in s -> "Don't mention it. Seriously, don't."
            "bye" in s -> "Leaving me on your screen? Bold. Bye."
            else -> pick(arrayOf("Mm. Say more.", "I'm listening, mostly.", "That's either deep or nonsense. I'm into it.", "Add a key in the app and I'll answer properly."))
        }
    }
}
