package app.capri.phone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.util.Linkify
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, 0, 0, pad / 2)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }
        col.addView(label("Capri", 30f))
        col.addView(label("A small companion that floats over your apps. Drag her, tap her, and she wanders and naps on her own.", 16f))
        col.addView(btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2. Start Capri") { startCapri() })
        col.addView(btn("Stop Capri") { stopService(Intent(this, CapriService::class.java)) })
        val credit = label("Unofficial fan project, not approved by CD PROJEKT RED or anyone behind the anime. Art and animations from Capri by lachydotmcg (https://github.com/lachydotmcg/capri-desktop), used under its non-commercial license with credit. Perch animations by her artist.", 12f)
        Linkify.addLinks(credit, Linkify.WEB_URLS)
        col.addView(credit)
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun startCapri() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first (button 1).", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, CapriService::class.java))
    }
}
