package app.capri.phone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.util.Linkify
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, pad / 3, 0, pad / 3)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }
        val prefs = getSharedPreferences("capri", 0)

        col.addView(label("Capri", 30f))
        col.addView(label("A small companion that floats over your apps. Tap her to talk, drag her around, and she wanders and naps on her own.", 16f))
        col.addView(btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2. Start Capri") { startCapri() })
        col.addView(btn("Stop Capri") { stopService(Intent(this, CapriService::class.java)) })

        col.addView(label("Her brain (optional)", 20f))
        col.addView(label("Without a key she uses simple scripted replies. With a key she answers in her own words. Your key stays on this phone and is only sent to the service you pick.", 13f))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Brain.NAMES)
        val sel = prefs.getInt("provider", 0).coerceIn(0, Brain.NAMES.size - 1)
        spinner.setSelection(sel)
        val keyEt = EditText(this).apply {
            hint = "Paste your key here"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val modelEt = EditText(this).apply {
            hint = "Model name"
            setText(prefs.getString("model", Brain.MODELS[sel]))
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val cur = modelEt.text.toString()
                if (cur.isBlank() || Brain.MODELS.contains(cur)) modelEt.setText(Brain.MODELS[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(spinner)
        col.addView(keyEt)
        col.addView(modelEt)
        col.addView(btn("Save brain settings") {
            prefs.edit()
                .putInt("provider", spinner.selectedItemPosition)
                .putString("key", keyEt.text.toString().trim())
                .putString("model", modelEt.text.toString().trim())
                .apply()
            Toast.makeText(this, "Saved. Tap Capri to talk.", Toast.LENGTH_SHORT).show()
        })
        val help = label("Free key: sign in at https://build.nvidia.com and create an API key. Other options: Gemini (https://aistudio.google.com), OpenAI, or Claude. If she says the model doesn't exist, change the model name above to a current one from that service.", 12f)
        Linkify.addLinks(help, Linkify.WEB_URLS)
        col.addView(help)

        val credit = label("Unofficial fan project, not approved by CD PROJEKT RED or anyone behind the anime. Art and animations from Capri by lachydotmcg (https://github.com/lachydotmcg/capri-desktop), used under its non-commercial license with credit. Perch animations by her artist.", 12f)
        Linkify.addLinks(credit, Linkify.WEB_URLS)
        col.addView(credit)
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun startCapri() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first (button 1).", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, CapriService::class.java))
    }
}
