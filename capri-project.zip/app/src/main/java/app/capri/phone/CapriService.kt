package app.capri.phone

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.AnimatedImageDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.hypot

class CapriService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var iv: ImageView? = null
    private val h = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()
    private var cur = ""
    private var perched = ""
    private var asleep = false
    private var dragging = false
    private var busy = false
    private var moved = false
    private var lastTouch = System.currentTimeMillis()
    private var anim: ValueAnimator? = null
    private var u = 0f
    private var sx = 0f
    private var sy = 0f
    private var ox = 0
    private var oy = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (iv == null && Settings.canDrawOverlays(this)) setup()
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        anim?.cancel()
        iv?.let { wm.removeView(it) }
        iv = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("capri", "Capri", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "capri")
            .setContentTitle("Capri is on your screen")
            .setContentText("Tap to open the app and stop her.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun setup() {
        u = resources.displayMetrics.density * 0.5f
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            (240 * u).toInt(), (384 * u).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dm.widthPixels - lp.width - 20
        lp.y = dm.heightPixels - lp.height - 200
        iv = view
        wm.addView(view, lp)
        view.setOnTouchListener(touch)
        show("idle")
        h.postDelayed(tick, 8000)
    }

    private fun base() = if (asleep) "sleep" else if (perched.isNotEmpty()) perched else "idle"

    private fun say(lines: Array<String>) =
        Toast.makeText(this, lines[rnd.nextInt(lines.size)], Toast.LENGTH_SHORT).show()

    // Same pixel scale for every animation so she never changes size. Her feet stay put when the frame changes.
    private fun show(k: String) {
        val v = iv ?: return
        if (cur == k) return
        cur = k
        val tall = k.startsWith("perch")
        val nw = ((if (tall) 150 else 240) * u).toInt()
        val nh = ((if (tall) 294 else 384) * u).toInt()
        lp.y += lp.height - nh
        lp.width = nw
        lp.height = nh
        val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(assets, "$k.webp"))
        v.setImageDrawable(d)
        (d as? AnimatedImageDrawable)?.let {
            it.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            it.start()
        }
        moveTo(lp.x, lp.y)
    }

    private fun moveTo(x: Int, y: Int) {
        val dm = resources.displayMetrics
        lp.x = x.coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = y.coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
        iv?.let { wm.updateViewLayout(it, lp) }
    }

    private fun glitch() {
        cur = ""
        show("glitch")
        busy = true
        h.postDelayed({ busy = false; if (!dragging) show(base()) }, 1500)
    }

    private val touch = View.OnTouchListener { _, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                anim?.cancel(); anim = null
                moved = false
                sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                lastTouch = System.currentTimeMillis()
                if (asleep) { asleep = false; glitch() }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - sx
                val dy = e.rawY - sy
                if (!moved && hypot(dx, dy) > ViewConfiguration.get(this).scaledTouchSlop) {
                    moved = true; perched = ""; busy = false
                    show("tossed")
                    say(arrayOf("Hey! Put me down gently!", "Whoa, whoa, whoa!"))
                }
                if (moved) moveTo(ox + dx.toInt(), oy + dy.toInt())
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (moved) {
                    perched = if (rnd.nextBoolean()) "perch" else "perchm"
                    show(perched)
                    say(arrayOf("Nice spot. I'll perch here.", "Landed. Mostly on my feet."))
                } else if (e.action == MotionEvent.ACTION_UP) {
                    glitch()
                    say(arrayOf("Boop received.", "You pressed my pixel.", "Tap noted."))
                }
            }
        }
        true
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (!asleep && !dragging && now - lastTouch > 180_000) {
                asleep = true; perched = ""; show("sleep")
            } else if (!asleep && !dragging && !busy && rnd.nextFloat() < 0.65f) {
                wander()
            }
            h.postDelayed(this, 8000)
        }
    }

    private fun wander() {
        perched = ""
        show("idle")
        val max = (resources.displayMetrics.widthPixels - lp.width).coerceAtLeast(0)
        val a = ValueAnimator.ofInt(lp.x, rnd.nextInt(max + 1))
        a.duration = 3000
        a.addUpdateListener { moveTo(it.animatedValue as Int, lp.y) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (dragging || asleep) return
                if (rnd.nextFloat() < 0.35f) {
                    perched = if (rnd.nextBoolean()) "perch" else "perchm"
                    show(perched)
                }
                if (rnd.nextFloat() < 0.25f) say(arrayOf("Just stretching my legs.", "New spot. Better view."))
            }
        })
        anim = a
        a.start()
    }
}
