package app.capri.phone

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

class CapriService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var iv: ImageView? = null
    private val h = Handler(Looper.getMainLooper())
    private val rnd = java.util.Random()
    private var cur = ""
    private var perched = ""
    private var asleep = false
    private var dragging = false
    private var busy = false
    private var moved = false
    private var lastTouch = System.currentTimeMillis()
    private var anim: ValueAnimator? = null
    private var u = 0f
    private var sx = 0f
    private var sy = 0f
    private var ox = 0
    private var oy = 0

    // speech bubble
    private var root: BubbleRoot? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var bg: BubbleBg
    private lateinit var msgTv: TextView
    private lateinit var input: EditText
    private var bw = 0
    private var bh = 0
    private var typing = false
    private var thinking = false
    private var reveal: Runnable? = null
    private val history = ArrayList<Pair<String, String>>()
    private val hideR = Runnable { if (!typing && !thinking) hideBubble() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (iv == null && Settings.canDrawOverlays(this)) setup()
        return START_STICKY
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        anim?.cancel()
        hideBubble()
        iv?.let { wm.removeView(it) }
        iv = null
        super.onDestroy()
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("capri", "Capri", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "capri")
            .setContentTitle("Capri is on your screen")
            .setContentText("Tap to open the app and stop her.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun setup() {
        u = resources.displayMetrics.density * 0.5f
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            (240 * u).toInt(), (384 * u).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dm.widthPixels - lp.width - 20
        lp.y = dm.heightPixels - lp.height - 200
        iv = view
        wm.addView(view, lp)
        view.setOnTouchListener(touch)
        show("idle")
        buildBubble()
        h.postDelayed({ showMsg("Hi. I'm Capri. Tap this bubble to talk to me.") }, 800)
        h.postDelayed(tick, 8000)
    }

    // ---------- speech bubble ----------

    private fun buildBubble() {
        val d = resources.displayMetrics.density
        bg = BubbleBg(dp(14f), d)
        val r = BubbleRoot(this) { closeInput() }
        r.orientation = LinearLayout.VERTICAL
        r.background = bg
        r.setPadding(dp(16f), dp(12f), dp(16f), dp(12f) + dp(14f))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val bar = View(this)
        bar.setBackgroundColor(0xFFE2245E.toInt())
        top.addView(bar, LinearLayout.LayoutParams(dp(3f), LinearLayout.LayoutParams.MATCH_PARENT))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10f), 0, 0, 0)
        val name = TextView(this)
        name.text = "CAPRI >"
        name.textSize = 12f
        name.setTextColor(0xFFF7D418.toInt())
        name.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        msgTv = TextView(this)
        msgTv.textSize = 14f
        msgTv.setTextColor(0xFFF0F0F5.toInt())
        msgTv.typeface = Typeface.MONOSPACE
        msgTv.setPadding(0, dp(4f), 0, dp(6f))
        col.addView(name)
        col.addView(msgTv)
        top.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        r.addView(DashView(this), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(6f)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val you = TextView(this)
        you.text = "YOU > "
        you.textSize = 12f
        you.setTextColor(0xFF28E2EC.toInt())
        you.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        input = EditText(this)
        input.background = null
        input.hint = "say something..."
        input.setHintTextColor(0xFF787D87.toInt())
        input.setTextColor(0xFFF0F0F5.toInt())
        input.typeface = Typeface.MONOSPACE
        input.textSize = 13f
        input.setPadding(0, dp(4f), 0, dp(4f))
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setRawInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        input.setHorizontallyScrolling(false)
        input.maxLines = 3
        if (Build.VERSION.SDK_INT >= 29) {
            val c = GradientDrawable()
            c.setColor(0xFF28E2EC.toInt())
            c.setSize(dp(2f), dp(16f))
            input.setTextCursorDrawable(c)
        }
        input.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN && !typing) openInput()
            false
        }
        input.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { if (typing) { measureBubble(); positionBubble() } }
        })
        row.addView(you)
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        r.setOnClickListener { openInput() }
        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && typing) closeInput()
            false
        }

        bw = minOf(resources.displayMetrics.widthPixels - dp(24f), dp(300f))
        bubbleLp = WindowManager.LayoutParams(
            bw, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        bubbleLp.gravity = Gravity.TOP or Gravity.START
        bubbleLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        root = r
    }

    private fun measureBubble() {
        val r = root ?: return
        r.measure(View.MeasureSpec.makeMeasureSpec(bw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        bh = r.measuredHeight
    }

    // Bubble sits above her head and its tail points at her.
    private fun positionBubble() {
        val r = root ?: return
        if (iv == null || bh == 0) return
        val dm = resources.displayMetrics
        val cx = lp.x + lp.width / 2
        val bx = (cx - bw * 0.6f).toInt().coerceIn(0, maxOf(0, dm.widthPixels - bw))
        var by = lp.y + (lp.height * 0.06f).toInt() - bh
        if (typing) by = minOf(by, dm.heightPixels / 2 - bh)
        by = by.coerceIn(0, maxOf(0, dm.heightPixels - bh))
        bg.tailFrac = ((cx - bx).toFloat() / bw).coerceIn(0.12f, 0.88f)
        bg.invalidateSelf()
        bubbleLp.x = bx
        bubbleLp.y = by
        bubbleLp.height = bh
        if (r.parent != null) wm.updateViewLayout(r, bubbleLp)
    }

    private fun showMsg(t: String) {
        val r = root ?: return
        h.removeCallbacks(hideR)
        reveal?.let { h.removeCallbacks(it) }
        msgTv.text = t
        measureBubble()
        positionBubble()
        if (r.parent == null) wm.addView(r, bubbleLp)
        var i = 0
        val run = object : Runnable {
            override fun run() {
                i = minOf(i + 2, t.length)
                val s = SpannableString(t)
                if (i < t.length) s.setSpan(ForegroundColorSpan(Color.TRANSPARENT), i, t.length, 0)
                msgTv.text = s
                if (i < t.length) h.postDelayed(this, 28) else scheduleHide(t.length)
            }
        }
        reveal = run
        run.run()
    }

    private fun scheduleHide(len: Int) {
        h.removeCallbacks(hideR)
        h.postDelayed(hideR, 5000L + len * 45L)
    }

    private fun hideBubble() {
        reveal?.let { h.removeCallbacks(it) }
        h.removeCallbacks(hideR)
        typing = false
        root?.let { if (it.parent != null) wm.removeView(it) }
    }

    private fun openInput() {
        val r = root ?: return
        if (typing) return
        typing = true
        lastTouch = System.currentTimeMillis()
        h.removeCallbacks(hideR)
        bubbleLp.flags = bubbleLp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        bubbleLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING or
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        positionBubble()
        input.requestFocus()
        h.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, 150)
        if (r.parent == null) wm.addView(r, bubbleLp)
    }

    private fun closeInput() {
        val r = root ?: return
        if (!typing) return
        typing = false
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
        bubbleLp.flags = bubbleLp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        measureBubble()
        positionBubble()
        if (!thinking) scheduleHide(msgTv.text.length)
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        closeInput()
        lastTouch = System.currentTimeMillis()
        if (asleep) { asleep = false; glitch() }
        history.add("user" to t)
        while (history.size > 12) history.removeAt(0)
        thinking = true
        showMsg("...")
        val snapshot = ArrayList(history)
        Thread {
            val r = Brain.ask(this, snapshot)
            h.post {
                thinking = false
                if (r.ok) {
                    history.add("assistant" to r.text)
                    while (history.size > 12) history.removeAt(0)
                }
                showMsg(r.text)
            }
        }.start()
    }

    private fun say(lines: Array<String>) {
        if (typing || thinking) return
        showMsg(lines[rnd.nextInt(lines.size)])
    }

    // ---------- Capri herself ----------

    private fun base() = if (asleep) "sleep" else if (perched.isNotEmpty()) perched else "idle"

    // Same pixel scale for every animation so she never changes size. Her feet stay put when the frame changes.
    private fun show(k: String) {
        val v = iv ?: return
        if (cur == k) return
        cur = k
        val tall = k.startsWith("perch")
        val nw = ((if (tall) 150 else 240) * u).toInt()
        val nh = ((if (tall) 294 else 384) * u).toInt()
        lp.y += lp.height - nh
        lp.width = nw
        lp.height = nh
        val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(assets, "$k.webp"))
        v.setImageDrawable(d)
        (d as? AnimatedImageDrawable)?.let {
            it.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
            it.start()
        }
        moveTo(lp.x, lp.y)
    }

    private fun moveTo(x: Int, y: Int) {
        val dm = resources.displayMetrics
        lp.x = x.coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = y.coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
        iv?.let { wm.updateViewLayout(it, lp) }
        positionBubble()
    }

    private fun glitch() {
        cur = ""
        show("glitch")
        busy = true
        h.postDelayed({ busy = false; if (!dragging) show(base()) }, 1500)
    }

    private val touch = View.OnTouchListener { _, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                anim?.cancel(); anim = null
                moved = false
                sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                lastTouch = System.currentTimeMillis()
                if (typing) closeInput()
                if (asleep) { asleep = false; glitch() }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - sx
                val dy = e.rawY - sy
                if (!moved && hypot(dx, dy) > ViewConfiguration.get(this).scaledTouchSlop) {
                    moved = true; perched = ""; busy = false
                    show("tossed")
                    say(arrayOf("Hey! Put me down gently!", "Whoa, whoa, whoa!"))
                }
                if (moved) moveTo(ox + dx.toInt(), oy + dy.toInt())
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (moved) {
                    perched = if (rnd.nextBoolean()) "perch" else "perchm"
                    show(perched)
                    say(arrayOf("Nice spot. I'll perch here.", "Landed. Mostly on my feet."))
                } else if (e.action == MotionEvent.ACTION_UP) {
                    glitch()
                    say(arrayOf("Boop received. Tap the bubble to talk.", "You pressed my pixel.", "Tap noted. Say something."))
                }
            }
        }
        true
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (!asleep && !dragging && !typing && !thinking && now - lastTouch > 180_000) {
                asleep = true; perched = ""; show("sleep"); hideBubble()
            } else if (!asleep && !dragging && !busy && !typing && !thinking && rnd.nextFloat() < 0.65f) {
                wander()
            }
            h.postDelayed(this, 8000)
        }
    }

    private fun wander() {
        perched = ""
        show("idle")
        val max = (resources.displayMetrics.widthPixels - lp.width).coerceAtLeast(0)
        val a = ValueAnimator.ofInt(lp.x, rnd.nextInt(max + 1))
        a.duration = 3000
        a.addUpdateListener { moveTo(it.animatedValue as Int, lp.y) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (dragging || asleep) return
                if (rnd.nextFloat() < 0.35f) {
                    perched = if (rnd.nextBoolean()) "perch" else "perchm"
                    show(perched)
                }
                if (rnd.nextFloat() < 0.25f) say(arrayOf("Just stretching my legs.", "New spot. Better view."))
            }
        })
        anim = a
        a.start()
    }
}
